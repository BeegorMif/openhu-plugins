<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name></name>
    <message id="org.openhu.radio.description">
        <source></source>
        <translation>FM/AM/DAB+ radio with an RTL-SDR USB stick: station scan, favorites, RDS (station name, radio text, PI) and DAB+ with DLS and slideshow (decoders included), station logos from your own image files. For testing without a stick: a simulated stick with internet radio streams.</translation>
    </message>
    <message id="org.openhu.radio.error.dab_ended">
        <source></source>
        <translation>openhu-dab ended</translation>
    </message>
    <message id="org.openhu.radio.error.dab_missing">
        <source></source>
        <translation>DAB unavailable, missing: %1</translation>
    </message>
    <message id="org.openhu.radio.error.dab_no_reception">
        <source></source>
        <translation>DAB: no reception of %1 (channel %2)</translation>
    </message>
    <message id="org.openhu.radio.error.dab_scan_failed">
        <source></source>
        <translation>DAB station scan failed: %1</translation>
    </message>
    <message id="org.openhu.radio.error.library_missing">
        <source></source>
        <translation>%1 cannot start: library %2 missing (package %3)</translation>
    </message>
    <message id="org.openhu.radio.error.no_dab_station">
        <source></source>
        <translation>No DAB station selected – start a station scan</translation>
    </message>
    <message id="org.openhu.radio.error.no_rtl_fm">
        <source></source>
        <translation>rtl_fm or pacat missing (packages rtl-sdr, pulseaudio-utils)</translation>
    </message>
    <message id="org.openhu.radio.error.no_stick">
        <source></source>
        <translation>No RTL-SDR stick found</translation>
    </message>
    <message id="org.openhu.radio.error.rtl_fm_ended">
        <source></source>
        <translation>rtl_fm ended</translation>
    </message>
    <message id="org.openhu.radio.error.scan_failed">
        <source></source>
        <translation>Station scan failed: %1</translation>
    </message>
    <message id="org.openhu.radio.error.scan_fm_only">
        <source></source>
        <translation>Station scan only for FM, needs rtl_power</translation>
    </message>
    <message id="org.openhu.radio.error.stick_busy">
        <source></source>
        <translation>The RTL-SDR stick is in use by another program</translation>
    </message>
    <message id="org.openhu.radio.error.unknown_dab_station">
        <source></source>
        <translation>Unknown DAB station %1 – start a station scan</translation>
    </message>
    <message id="org.openhu.radio.error.unknown_pi">
        <source></source>
        <translation>Station with PI %1 unknown</translation>
    </message>
    <message id="org.openhu.radio.main.all_stations">
        <source></source>
        <translation>All stations</translation>
    </message>
    <message id="org.openhu.radio.main.cancel">
        <source></source>
        <translation>Cancel</translation>
    </message>
    <message id="org.openhu.radio.main.choose_station">
        <source></source>
        <translation>Choose a station</translation>
    </message>
    <message id="org.openhu.radio.main.dab_missing">
        <source></source>
        <translation>DAB unavailable, missing: %1</translation>
    </message>
    <message id="org.openhu.radio.main.favorite">
        <source></source>
        <translation>Favorite</translation>
    </message>
    <message id="org.openhu.radio.main.favorites">
        <source></source>
        <translation>Favorites</translation>
    </message>
    <message id="org.openhu.radio.main.next_station">
        <source></source>
        <translation>Next station</translation>
    </message>
    <message id="org.openhu.radio.main.no_stations">
        <source></source>
        <translation>No stations yet – start a scan</translation>
    </message>
    <message id="org.openhu.radio.main.no_stations_am">
        <source></source>
        <translation>Keep stations with the heart</translation>
    </message>
    <message id="org.openhu.radio.main.play">
        <source></source>
        <translation>Play</translation>
    </message>
    <message id="org.openhu.radio.main.previous_station">
        <source></source>
        <translation>Previous station</translation>
    </message>
    <message id="org.openhu.radio.main.rds_missing">
        <source></source>
        <translation>RDS unavailable, missing: %1</translation>
    </message>
    <message id="org.openhu.radio.main.scan">
        <source></source>
        <translation>Scan</translation>
    </message>
    <message id="org.openhu.radio.main.scanning">
        <source></source>
        <translation>Scanning …</translation>
    </message>
    <message id="org.openhu.radio.main.scanning_channel">
        <source></source>
        <translation>Scanning … channel %1 (%2/%3), %4 stations</translation>
    </message>
    <message id="org.openhu.radio.main.simulated_stick">
        <source></source>
        <translation>Simulated stick</translation>
    </message>
    <message id="org.openhu.radio.main.stations">
        <source></source>
        <translation>Stations</translation>
    </message>
    <message id="org.openhu.radio.main.step_down">
        <source></source>
        <translation>Lower frequency (hold for faster)</translation>
    </message>
    <message id="org.openhu.radio.main.step_up">
        <source></source>
        <translation>Higher frequency (hold for faster)</translation>
    </message>
    <message id="org.openhu.radio.main.stop">
        <source></source>
        <translation>Stop</translation>
    </message>
    <message id="org.openhu.radio.name">
        <source></source>
        <translation>Radio</translation>
    </message>
    <message id="org.openhu.radio.settings.biasTee">
        <source></source>
        <translation>Antenna power (bias-T)</translation>
    </message>
    <message id="org.openhu.radio.settings.biasTee.description">
        <source></source>
        <translation>Powers an active antenna through the stick (DAB+)</translation>
    </message>
    <message id="org.openhu.radio.settings.gain">
        <source></source>
        <translation>Tuner gain (dB)</translation>
    </message>
    <message id="org.openhu.radio.settings.gain.auto">
        <source></source>
        <translation>Auto</translation>
    </message>
    <message id="org.openhu.radio.settings.gain.description">
        <source></source>
        <translation>Lower it when strong stations distort</translation>
    </message>
    <message id="org.openhu.radio.settings.pauseForAndroidAuto">
        <source></source>
        <translation>Pause for other sources</translation>
    </message>
    <message id="org.openhu.radio.settings.pauseForAndroidAuto.description">
        <source></source>
        <translation>Stops when Android Auto or another source starts playing</translation>
    </message>
    <message id="org.openhu.radio.settings.playback">
        <source></source>
        <translation>Playback</translation>
    </message>
    <message id="org.openhu.radio.settings.ppm">
        <source></source>
        <translation>Frequency correction (ppm)</translation>
    </message>
    <message id="org.openhu.radio.settings.ppm.description">
        <source></source>
        <translation>For sticks whose stations are slightly off</translation>
    </message>
    <message id="org.openhu.radio.settings.rds">
        <source></source>
        <translation>RDS</translation>
    </message>
    <message id="org.openhu.radio.settings.rds.description">
        <source></source>
        <translation>Station names and radio text on FM</translation>
    </message>
    <message id="org.openhu.radio.settings.tuner">
        <source></source>
        <translation>USB stick</translation>
    </message>
</context>
</TS>
